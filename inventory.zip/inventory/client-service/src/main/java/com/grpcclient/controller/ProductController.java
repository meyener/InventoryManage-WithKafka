package com.grpcclient.controller;

import com.grpcclient.service.ProductClientService;
import com.grpcdata.entity.Product;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;


@RestController
@RequiredArgsConstructor
@RequestMapping("api/v1/products")
public class ProductController {

    private final ProductClientService clientService;

    @GetMapping("/product/{id}")
    public ResponseEntity<Product> getById(@PathVariable String id){
    Product response=clientService.getById(Integer.parseInt(id));
    return ResponseEntity.ok(response);
    }

    @GetMapping("/")
    public List<Product> getAll(){
        return clientService.getAll();
    }

    @PostMapping("/product/")
    public void create(@RequestBody Product product){
       ResponseEntity.ok(clientService.create(product));
    }


    @PostMapping("/delete/{id}")
    public void delete(@PathVariable int id){
        ResponseEntity.ok(clientService.delete(id));
    }

    @PostMapping("/setQuantity/{id}")
    public void setQuantity(@PathVariable int id, @RequestBody Product product){
        ResponseEntity.ok(clientService.setQuantity(id,product));
    }
}
