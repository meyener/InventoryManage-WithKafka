package com.grpcclient.service;

import com.garanti.grpc.*;
import com.grpcdata.entity.Product;
import net.devh.boot.grpc.client.inject.GrpcClient;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ProductClientService {

    @GrpcClient("grpc-task2-service")
    ProductServiceGrpc.ProductServiceBlockingStub blockingStub;

    @GrpcClient("grpc-task2-service")
    ProductServiceGrpc.ProductServiceStub serviceStub;

    private final KafkaTemplate<String,String> kafkaTemplate;


    public ProductClientService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public Product getById(int id){
        ProductRequest productRequest=ProductRequest.newBuilder().setId(id).build();

        ProductResponse productResponse=this.blockingStub.getById(productRequest);

        return  Product.builder().id(productResponse.getId()).
                name(productResponse.getName()).
                category(productResponse.getCategory()).
                quantity(productResponse.getQuantity()).
                IsDeleted(productResponse.getIsDeleted()).build();
    }

    public List<Product> getAll(){

        Empty empty=Empty.newBuilder().build();

        ListOfProducts listOfProducts=this.blockingStub.getAll(empty);

        List<ProductResponse> productResponses=listOfProducts.getResponseList();

        List<Product> products=new ArrayList<>();

        for (ProductResponse response:productResponses) {
            Product product=Product.builder().id(response.getId()).
                    name(response.getName()).
                    category(response.getCategory()).
                    quantity(response.getQuantity()).
                    IsDeleted(response.getIsDeleted()).build();
            products.add(product);

        }
        return products;
    }

    public boolean create(Product product){

        com.garanti.grpc.Product coproduct= com.garanti.grpc.Product.
                newBuilder().
                setId(product.getId()).
                setName(product.getName()).
                setCategory(product.getCategory()).
                setQuantity(product.getQuantity()).
                setIsDeleted(product.isIsDeleted()).build();

        IsCompleted isCompleted=blockingStub.create(coproduct);
        return isCompleted.getComplete();
    }

    public boolean delete(int id){

        ProductRequest request=ProductRequest.newBuilder().setId(id).build();

        IsCompleted isCompleted=blockingStub.delete(request);

        return isCompleted.getComplete();
    }

    public boolean setQuantity(int id,Product product){
        ProductRequest request=ProductRequest.newBuilder().setId(id).build();
        ProductResponse productResponse=this.blockingStub.getById(request);

        com.garanti.grpc.Product productGrpc= com.garanti.grpc.Product.newBuilder().
                setId(productResponse.getId()).
                setName(productResponse.getName()).
                setCategory(productResponse.getCategory()).
                setQuantity(productResponse.getQuantity()- product.getQuantity()).
                setIsDeleted(productResponse.getIsDeleted()).build();

        return this.blockingStub.setQuantity(productGrpc).getComplete();
    }
}
