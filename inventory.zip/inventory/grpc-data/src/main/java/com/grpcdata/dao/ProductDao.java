package com.grpcdata.dao;

import com.grpcdata.entity.Product;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ProductDao<T> {


    T getById(int id);

    List<T> getAll();

    boolean create(T t);

    boolean update(T t,int id);



}
