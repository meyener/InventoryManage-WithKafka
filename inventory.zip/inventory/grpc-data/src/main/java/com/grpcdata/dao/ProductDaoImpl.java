package com.grpcdata.dao;

import com.grpcdata.entity.Product;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Component
public class ProductDaoImpl implements ProductDao<Product> {

    private static final Logger LOGGER= LoggerFactory.getLogger(Product.class);

    private final JdbcTemplate jdbcTemplate;

    RowMapper<Product> rowMapper=(rs, rowNum)->{
        Product product=new Product();
        product.setId(rs.getInt("id"));
        product.setName(rs.getString("name"));
        product.setCategory(rs.getString("category"));
        product.setQuantity(rs.getInt("quantity"));
        product.setIsDeleted(rs.getBoolean("isDeleted"));
        return product;};


    public ProductDaoImpl(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    @Override
    public Product getById(int id) {
        String sql="SELECT id,name,category,quantity,isDeleted FROM products WHERE id=?";
        try {
            return jdbcTemplate.queryForObject(sql,new Object[]{id},rowMapper);
        }catch (EmptyResultDataAccessException e){

            LOGGER.error("Product not found !!!");
            return new Product();
        }
    }

    @Override
    public List<Product> getAll() {
        String sql="SELECT id,name,category,quantity,isDeleted FROM products ";
        try {
            return jdbcTemplate.query(sql,rowMapper);
        }catch (EmptyResultDataAccessException e){

            LOGGER.error("Product not found !!!");
            return new ArrayList<>();
        }
    }

    @Override
    @Transactional
    public boolean create(Product product) {
        String sql="INSERT INTO products(name,category,quantity,isDeleted) values(?,?,?,?)";

        try{jdbcTemplate.update(sql,
                product.getName(),
                product.getCategory(),
                product.getQuantity(),
                product.isIsDeleted());
            return true;
        }
        catch (DataAccessException e){
            LOGGER.error("Product can not created!!!");
            return false;
        }
    }

    @Override
    @Transactional
    public boolean update(Product product,int id) {
        String sql="update products set name=?, category=?,quantity=?,isDeleted=? where id=?";
        try{
            jdbcTemplate.update(sql,
                    product.getName(),
                    product.getCategory(),
                    product.getQuantity(),
                    product.isIsDeleted(), id);
            return true;
        }catch (DataAccessException e){
            LOGGER.error("Can not updated");
            return false;
        }
    }

//    @Override
//    public boolean setQuantity(int amount,int id) {
//        Product product=getById(id);
//
//            try{
//                if (amount>= product.getQuantity()) {
//                    product.setQuantity(product.getQuantity()-amount);
//                }
//                    update(product,id);
//
//                    return true;
//            }catch(DataAccessException e){
//                return false;
//            }



}
