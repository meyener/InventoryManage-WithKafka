package com.grpcdata.dao;

import com.grpcdata.entity.Product;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.when;

class ProductDaoImplTest {

    @InjectMocks
    private ProductDaoImpl productDao;

    @Mock
    private JdbcTemplate jdbcTemplate;


    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetById_ProductFound() {
        Product expectedProduct = new Product(1, "Test-Product", "test", 10, false);

        when(jdbcTemplate.queryForObject(anyString(), any(Object[].class), any(RowMapper.class)))
                .thenReturn(expectedProduct);

        Product resultProduct = productDao.getById(1);

        assertNotNull(resultProduct);
        assertEquals(expectedProduct.getId(), resultProduct.getId());
        assertEquals(expectedProduct.getName(), resultProduct.getName());
        assertEquals(expectedProduct.getCategory(), resultProduct.getCategory());
        assertEquals(expectedProduct.getQuantity(), resultProduct.getQuantity());
        assertEquals(expectedProduct.isIsDeleted(), resultProduct.isIsDeleted());
    }


}