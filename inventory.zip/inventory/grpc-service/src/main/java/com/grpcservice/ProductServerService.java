package com.grpcservice;

import java.util.List;
import io.grpc.Status;
import com.garanti.grpc.*;
import java.util.ArrayList;
import com.grpcdata.dao.ProductDao;
import io.grpc.stub.StreamObserver;
import com.grpcdata.entity.Product;
import net.devh.boot.grpc.server.service.GrpcService;
import org.springframework.kafka.core.KafkaTemplate;

@GrpcService
public class ProductServerService extends ProductServiceGrpc.ProductServiceImplBase {

    private final ProductDao<Product> productDao;
    private final KafkaTemplate<String,String> kafkaTemplate;
    private String topic="new-topic";
    private String message="heloooo";

    public ProductServerService(ProductDao<Product> productDao, KafkaTemplate<String, String> kafkaTemplate) {
        this.productDao = productDao;
        this.kafkaTemplate = kafkaTemplate;
    }

    @Override
    public void getById(ProductRequest request, StreamObserver<ProductResponse> responseObserver) {
        Product product=productDao.getById(request.getId());

        if(product==null){
            responseObserver.
                    onError(Status.NOT_FOUND.
                            withDescription("Object could not found !!").
                            asRuntimeException());
        }else{
            ProductResponse response=ProductResponse.newBuilder().
                    setId(product.getId()).
                    setName(product.getName()).
                    setCategory(product.getCategory()).
                    setQuantity(product.getQuantity()).
                    setIsDeleted(product.isIsDeleted()).build();

                    responseObserver.onNext(response);

        }responseObserver.onCompleted();
    }


    @Override
    public void getAll(Empty request, StreamObserver<ListOfProducts> responseObserver) {

        List<Product> products=productDao.getAll();

        List<ProductResponse> productResponseList=new ArrayList<>();

        for (Product product:products) {
            ProductResponse response=ProductResponse.newBuilder().
                    setId(product.getId()).
                    setName(product.getName()).
                    setCategory(product.getCategory()).
                    setQuantity(product.getQuantity()).
                    setIsDeleted(product.isIsDeleted()).build();

                    productResponseList.add(response);}

                ListOfProducts listOfProducts=ListOfProducts.
                newBuilder().
                addAllResponse(productResponseList).
                build();

        responseObserver.onNext(listOfProducts);

        responseObserver.onCompleted();

    }


    @Override
    public void update(com.garanti.grpc.Product request, StreamObserver<IsCompleted> responseObserver) {
        int id=request.getId();
        Product product=new Product();
        product.setId(request.getId());
        product.setName(request.getName());
        product.setCategory(request.getCategory());
        product.setQuantity(request.getQuantity());
        product.setIsDeleted(request.getIsDeleted());

        boolean res=productDao.update(product,id);

        if (res){
            IsCompleted isCompleted=IsCompleted.newBuilder().setComplete(res).build();
            responseObserver.onNext(isCompleted);

        }else {
            responseObserver.onError(Status.
                    UNAVAILABLE.
                    withDescription("Somethings went wrong :)").
                    asRuntimeException());
        }
        responseObserver.onCompleted();
    }


    @Override
    public void create(com.garanti.grpc.Product request, StreamObserver<IsCompleted> responseObserver) {

        Product product=new Product();
        product.setName(request.getName());
        product.setCategory(request.getCategory());
        product.setQuantity(request.getQuantity());
        product.setIsDeleted(request.getIsDeleted());


        boolean res=productDao.create(product);

        if (res){
            IsCompleted isCompleted=IsCompleted.newBuilder().setComplete(res).build();
            responseObserver.onNext(isCompleted);

        }else {
            responseObserver.onError(Status.
                    UNAVAILABLE.
                    withDescription("Somethings went wrong :)").
                    asRuntimeException());
        }
        responseObserver.onCompleted();
    }


    @Override
    public void delete(ProductRequest request, StreamObserver<IsCompleted> responseObserver) {

        Product product =productDao.getById(request.getId());
        int id=request.getId();
        product.setIsDeleted(true);

        boolean result=productDao.update(product,id);

        if (result){
            IsCompleted isCompleted= IsCompleted.newBuilder().setComplete(result).build();
            responseObserver.onNext(isCompleted);
        }else {
            responseObserver.
                    onError(Status.UNIMPLEMENTED.
                            withDescription("Soft delete did not work please try hard delete :P").
                            asRuntimeException());
        }
        responseObserver.onCompleted();
    }

    @Override
    public void setQuantity(com.garanti.grpc.Product request, StreamObserver<IsCompleted> responseObserver) {

            Product product=Product.builder().
                    id(request.getId()).
                    name(request.getName()).
                    category(request.getCategory()).
                    quantity(request.getQuantity()).
                    IsDeleted(request.getIsDeleted()).build();

            IsCompleted isCompleted=IsCompleted.newBuilder().
                    setComplete(productDao.update(product, request.getId()))
                    .build();

            kafkaTemplate.send( topic, product.getQuantity()<=0 ?
                    "Stok bitmek üzere !!! " +product.getName()+" "+" "+product.getQuantity():
                    "mevcut stok of"+product.getName()+" :"+" "+product.getQuantity() );

            responseObserver.onNext(isCompleted);



        responseObserver.onCompleted();
    }



}
