package com.grpcservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;

@SpringBootApplication(scanBasePackages={"com.grpcdata.dao","com.grpcservice"})
@Import(ProductServerService.class)
public class ServiceApplication {


    public static void main(String[] args) {

        SpringApplication.run(ServiceApplication.class,args);
    }
}
