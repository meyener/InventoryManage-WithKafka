package com.grpcservice;

import com.garanti.grpc.ProductRequest;
import com.garanti.grpc.ProductResponse;
import com.grpcdata.dao.ProductDao;
import com.grpcdata.entity.Product;
import io.grpc.Status;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class ProductServerServiceTest {

    @InjectMocks// this annotation provides to inject Mock inside Test class
    private ProductServerService service;
    @Mock       // this annotation provides to compose fake instance of object
    private ProductDao<Product> productDao;
    @Mock       // same here
    private StreamObserver<ProductResponse> responseObserver;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testGetById_WhenValidProduct() {
        Product product = new Product(1, " test-Product", "test-catogry", 10, false);//  random instance of product
        when(productDao.getById(1)).thenReturn(product);// in there kinda simulating to invoke  getById method after all in thenReturn,
                                                        //  demonstrating return of this method
        ProductRequest request = ProductRequest.newBuilder().setId(1).build();//instance of ProductRequest
        service.getById(request, responseObserver);// normally getById takes 2 parameters : ProductRequest request, StreamObserver<ProductResponse> responseObserver
                                                   // behaved like method work


        // ArgumentCaptor provides to catch values of argument which using as ProductResponse
        ArgumentCaptor<ProductResponse> responseCaptor = ArgumentCaptor.forClass(ProductResponse.class);
        //in this line, verifying that method of responseObserver invoked or not
        //also when at onNext call, we hold argument via responseCaptor
        verify(responseObserver).onNext(responseCaptor.capture());
        verify(responseObserver).onCompleted();


        // In there results have been checked
        ProductResponse response = responseCaptor.getValue();
        assertNotNull(response);
        assertEquals(response.getId(), product.getId());
        assertEquals(response.getName(), product.getName());
        assertEquals(response.getCategory(), product.getCategory());
        assertEquals(response.getQuantity(), product.getQuantity());
        assertFalse(response.getIsDeleted());

    }



}